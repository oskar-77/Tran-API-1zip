"""Unit tests for Document Processing Agent."""
