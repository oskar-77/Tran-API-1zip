---
title: "fa957811_test_excel.xlsx"
author: "openpyxl"
date: "2025-12-05T21:30:19"
source_format: "xlsx"
dir: rtl
---

# fa957811_test_excel.xlsx

## TestSheet

| اختبار مكتبة قراءة ملفات Excel |  |  |
| ------------------------------ | --- | --- |
| جدول بيانات تجريبي: |  |  |
| الرقم | الاسم | القسم |
| 1 | أحمد | تقنية |
| 2 | منى | إدارة |
| 3 | سالم | تسويق |
