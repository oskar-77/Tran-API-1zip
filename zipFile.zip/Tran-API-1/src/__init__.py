"""Document Processing Agent - A comprehensive document extraction and conversion system."""

__version__ = "1.0.0"
